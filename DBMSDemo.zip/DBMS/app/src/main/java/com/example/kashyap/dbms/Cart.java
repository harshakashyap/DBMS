package com.example.kashyap.dbms;

import android.content.Intent;
import android.database.Cursor;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.widget.TextView;

import java.util.ArrayList;

public class Cart extends AppCompatActivity {

    TextView Name, Phone, User;
    String CartPhone;
    CartAdapter CA;
    RecyclerView RV;
    CartItems CI;
    ArrayList<CartItems> AL;
    DBHelper DBH;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_cart);
        Name = (TextView) findViewById(R.id.CartName);
        Phone = (TextView) findViewById(R.id.CartPhone);
        User = (TextView) findViewById(R.id.CartUser);

        RV = (RecyclerView) findViewById(R.id.CartRV);
        DBH = new DBHelper(this);
        Intent intent = getIntent();
        CartPhone = intent.getStringExtra("Phone");
        Cursor cursor = DBH.getCartDetails(Name, CartPhone);
        Phone.setText(CartPhone);
        cursor.moveToFirst();
        User.setText(cursor.getString(0));
        cursor.close();

        /*Cursor cursor1 = DBH.dispTrans(CartPhone);
        cursor1.moveToFirst();

        int i=0;
        while(i<cursor1.getCount())
        {
            CI = new CartItems(cursor1.getString(0), cursor1.getLong(2), cursor1.getLong(1));
            AL.add(CI);
            cursor1.moveToNext();
            i++;
        }
        CA = new CartAdapter(AL);
        RV.setLayoutManager(new LinearLayoutManager(this));
        RV.setHasFixedSize(true);
        RV.setAdapter(CA);*/
    }
}
