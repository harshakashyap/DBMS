package com.example.kashyap.dbms;

/**
 * Created by kashyap on 21/11/17.
 */

public class CartItems {
    String PID;
    long Cost, Qty;

    public CartItems(String a, long b, long c)
    {
        PID = a;
        Cost = b;
        Qty = c;
    }
}
