package com.example.kashyap.dbms;

/**
 * Created by kashyap on 12/11/17.
 */

public class MBdata {
    public String MBno, Manufacturer, Cost, Stock;

    public MBdata(String a, String b, String c, String d)
    {
        MBno = a;
        Manufacturer = b;
        Cost = c;
        Stock = d;
    }

    public MBdata(){

    }
}
