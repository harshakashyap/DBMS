package com.example.kashyap.dbms;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import android.widget.Toast;

public class AdvancedAdmin extends AppCompatActivity {

    EditText PK, Table, StockNo;
    DBHelper DBH;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_advanced_admin);
        DBH = new DBHelper(this);
        PK = (EditText) findViewById(R.id.PK);
        Table = (EditText) findViewById(R.id.Table);
        StockNo = (EditText) findViewById(R.id.StockQty);

    }

    public void AddStock(View view) {
        String PKey, TN, Qty;
        PKey = PK.getText().toString();
        TN = Table.getText().toString();
        Qty = StockNo.getText().toString();

        DBH.ReplenishStock(PKey, TN, Qty);
        Toast.makeText(this, "The stock is updated", Toast.LENGTH_SHORT).show();
        finish();
    }
}
