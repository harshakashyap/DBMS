package com.example.kashyap.dbms;

import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import java.util.ArrayList;

/**
 * Created by kashyap on 21/11/17.
 */

public class CartAdapter extends RecyclerView.Adapter<CartAdapter.VH> {

    ArrayList<CartItems> AL;

    public CartAdapter(ArrayList AL)
    {
        this.AL = AL;
    }
    @Override
    public VH onCreateViewHolder(ViewGroup parent, int viewType) {
        LayoutInflater LI = LayoutInflater.from(parent.getContext());
        View V = LI.inflate(R.layout.cart_item,parent,false);
        VH vh = new VH(V);
        return vh;
    }

    @Override
    public void onBindViewHolder(VH holder, int position) {
        holder.QtyDisp.setText((int) AL.get(position).Qty);
        holder.PIDDisp.setText(AL.get(position).PID);
        holder.CostDisp.setText((int) AL.get(position).Cost);
    }

    @Override
    public int getItemCount() {
        return AL.size();
    }

    public class VH extends RecyclerView.ViewHolder{

        TextView PIDlabel, Costlabel, Qtylabel;
        TextView PIDDisp, CostDisp, QtyDisp;

        public VH(View itemView) {
            super(itemView);
            PIDDisp = itemView.findViewById(R.id.PIDdisp);
            Costlabel = itemView.findViewById(R.id.CostLabel);
            Qtylabel = itemView.findViewById(R.id.Qtylabel);
            PIDlabel = itemView.findViewById(R.id.PIDlabel);
            CostDisp = itemView.findViewById(R.id.CostDisp);
            QtyDisp = itemView.findViewById(R.id.QtyDisp);

        }
    }
}
