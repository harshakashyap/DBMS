package com.example.kashyap.dbms;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.TextView;

public class AdminLogin extends AppCompatActivity {

    TextView Agg1, Agg2, Agg3, Agg4, Agg5, Agg6;
    DBHelper DBH;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_admin_login);
        Agg1 = (TextView) findViewById(R.id.Ag1);
        Agg2 = (TextView) findViewById(R.id.Ag2);
        Agg3 = (TextView) findViewById(R.id.Ag3);
        Agg4 = (TextView) findViewById(R.id.Ag4);
        Agg5 = (TextView) findViewById(R.id.Ag5);
        Agg6 = (TextView) findViewById(R.id.Ag6);
        DBH = new DBHelper(this);

        Agg1.setText(String.valueOf(DBH.getSum()));
        Agg2.setText(String.valueOf(DBH.totalDevices()));
        Agg3.setText(DBH.avgRAMval());
        Agg4.setText(DBH.CostliestProc());
        Agg5.setText(DBH.CheapestMB());
        Agg6.setText(DBH.Intel());
    }

    public void Advanced(View view) {
        Intent intent = new Intent(AdminLogin.this,AdvancedAdmin.class);
        startActivity(intent);
    }
}
