package com.example.kashyap.dbms;

import android.content.Context;
import android.database.Cursor;
import android.database.DatabaseErrorHandler;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import android.widget.TextView;

import java.util.Random;

/**
 * Created by kashyap on 7/11/17.
 */

public class DBHelper extends SQLiteOpenHelper {

    public DBHelper(Context context) {
        super(context,"Warehouse", null, 1);
    }

    @Override
    public void onCreate(SQLiteDatabase sqLiteDatabase) {
        sqLiteDatabase.execSQL("create table Login ( Username text primary key, Password text, Phone integer ) ");
        sqLiteDatabase.execSQL("create table Customers ( Name text, Phone INTEGER references Login(Phone), Email text ) "); //Check for errors here
        sqLiteDatabase.execSQL("create table RAM (RAMno text primary key, Manufacturer text, Size text, Type text, Cost integer, Stock integer ) ");
        sqLiteDatabase.execSQL("create table Processor (ProcNo text primary key, Manufacturer text, Cores integer, Clock text, Cost integer, Stock integer) ");
        sqLiteDatabase.execSQL("create table Motherboard (MBNo text primary key, Manufacturer text, Cost integer, Stock integer) ");
        sqLiteDatabase.execSQL("create table Transact (Phone integer , ProductID text, Cost integer) ");
        init(sqLiteDatabase);

    }

    private void init(SQLiteDatabase sqLiteDatabase) {
        sqLiteDatabase.execSQL("Insert into RAM values('CMX8GX3M2A1600C11', 'Corsair', '8GB', 'DDR3', 7479, 26 )");
        sqLiteDatabase.execSQL("Insert into RAM values('CMK16GX4M1A2400C14', 'Corsair', '16GB', 'DDR4', 14300, 35 )");
        sqLiteDatabase.execSQL("Insert into RAM values('F4-3000C16D-16GTZR', 'G.Skill Trident', '16GB', 'DDR4', 17300, 20 )");
        sqLiteDatabase.execSQL("Insert into RAM values('HX432C16PB3K4/16', 'Kingston', '16GB', 'DDR4', 26333, 21 )");
        sqLiteDatabase.execSQL("Insert into RAM values('F4-3000C15D-16GVR', 'G.Skill Ripjaws', '16GB', 'DDR4', 22453, 13 )");

        sqLiteDatabase.execSQL("Insert into Processor values ('i7 6950X', 'Intel', 10, '3.00Ghz', 145000, 12)");
        sqLiteDatabase.execSQL("Insert into Processor values ('i3 8100', 'Intel', 4, '3.60Ghz', 10499, 5)");
        sqLiteDatabase.execSQL("Insert into Processor values ('Ryzen 5 1500x', 'AMD', 4, '3.50Ghz', 15450, 20)");
        sqLiteDatabase.execSQL("Insert into Processor values ('Ryzen 5 1600x', 'AMD', 6, '3.60Ghz', 20300, 15)");
        sqLiteDatabase.execSQL("Insert into Processor values ('Ryzen 7 1700x', 'AMD', 8, '3.40Ghz', 29999, 32)");
        sqLiteDatabase.execSQL("Insert into Processor values ('i5 7100', 'Intel', 4, '3.40Ghz', 17399, 43)");
        sqLiteDatabase.execSQL("Insert into Processor values ('i5 7600', 'Intel', 4, '3.50Ghz', 18599, 23)");
        sqLiteDatabase.execSQL("Insert into Processor values ('i7 7700', 'Intel', 4, '3.60Ghz', 25193, 30)");
        sqLiteDatabase.execSQL("Insert into Processor values ('Ryzen 7 1800x', 'AMD', 8, '3.60Ghz', 38490, 2)");
        sqLiteDatabase.execSQL("Insert into Processor values ('i7 8700K', 'Intel', 6, '3.70Ghz', 37450, 10)");

        sqLiteDatabase.execSQL("Insert into Motherboard values ('GA-H110M-S2', 'GIGABYTE', 4343, 50) ");
        sqLiteDatabase.execSQL("Insert into Motherboard values ('GA-B250M-DS3H', 'GIGABYTE', 7080, 81) ");
        sqLiteDatabase.execSQL("Insert into Motherboard values ('B250F-ROG','Asus Strix',10600,49)");
        sqLiteDatabase.execSQL("Insert into Motherboard values ('Z270F-ROG','Asus Strix',15210,46)");
        sqLiteDatabase.execSQL("Insert into Motherboard values ('Z270-M3','MSI',16448,32)");
        sqLiteDatabase.execSQL("Insert into Motherboard values ('A320M PRO-VH+','MSI Ryzen',5599,30)");
        sqLiteDatabase.execSQL("Insert into Motherboard values ('Z370-A PRO','MSI',11805,24)");
        sqLiteDatabase.execSQL("Insert into Motherboard values ('GA-AB350','GIGABYTE Ryzen',8957,36)");
        sqLiteDatabase.execSQL("Insert into Motherboard values ('B350-PLUS','Asus PRIME Ryzen',8694,42)");
        sqLiteDatabase.execSQL("Insert into Motherboard values ('B350M-A','Asus PRIME',7745,39)");
    }

    @Override
    public void onUpgrade(SQLiteDatabase sqLiteDatabase, int i, int i1) {
        sqLiteDatabase.execSQL("drop table if exists Login");
        sqLiteDatabase.execSQL("drop table if exists Customers");
        sqLiteDatabase.execSQL("drop table if exists RAM");
        sqLiteDatabase.execSQL("drop table if exists Processor");
        sqLiteDatabase.execSQL("drop table if exists Motherboard");
        sqLiteDatabase.execSQL("drop table Transact");

        onCreate(sqLiteDatabase);
    }

    public boolean ifUserExists(String username,String password)
    {
        SQLiteDatabase db = this.getReadableDatabase();
        Cursor cursor;
        cursor = db.rawQuery("Select * from Login where Username = '"+username+"' and Password = '"+password+"' ",null);
        if(cursor!=null && cursor.getCount()!=0)
            return true;
        else return false;
    }

    public void registerUser(String username, String password, String name, String email, int phone)
    {
        SQLiteDatabase db = this.getWritableDatabase();
        db.execSQL("insert into Login values ( '"+username+"', '"+password+"', "+phone+" ) ");
        db.execSQL("insert into Customers values ( '"+name+"', '"+phone+"', '"+email+"' ) ");
    }

    public Cursor dispRAM()
    {
        SQLiteDatabase db = this.getReadableDatabase();
        Cursor cursor = db.rawQuery(" Select * from RAM ",null);
        return cursor;
    }

    public String retrivePhone(String s) {
        Cursor cursor;
        SQLiteDatabase db = this.getReadableDatabase();
        cursor = db.rawQuery("Select Phone from Login where Username = '"+s+"' ",null);
        cursor.moveToFirst();
        return cursor.getString(0);
    }

    public void updateStock(String TableName, String phone, String PKval, String PKname) {
        SQLiteDatabase db1 = this.getReadableDatabase();
        Cursor cursor = db1.rawQuery("Select Stock from "+TableName+" where "+PKname+" = '"+PKval+"' ",null);
        cursor.moveToFirst();
        int stock = Integer.parseInt(cursor.getString(0));
        cursor = db1.rawQuery(" Select Cost from '"+TableName+"' where "+PKname+" = '"+PKval+"' ",null);
        cursor.moveToFirst();
        int cost = cursor.getInt(0);
        db1.close();
        SQLiteDatabase db = this.getWritableDatabase();
        db.execSQL("Update "+TableName+" set Stock = "+(stock-1)+" where "+PKname+" = '"+PKval+"' ");
        db.execSQL("Insert into Transact values ('"+phone+"' , '"+PKval+"', "+cost+" )" );
        db.close();

    }

    public Cursor dispProc() {
        SQLiteDatabase db = this.getReadableDatabase();
        Cursor cursor = db.rawQuery(" Select * from Processor ",null);
        return cursor;
    }

    public Cursor dispTrans(String Phone)
    {
        SQLiteDatabase db = getReadableDatabase();
        Cursor cursor = db.rawQuery(" Select distinct ProductID, Count(*), Cost from Transact where Phone = '"+Phone+"' ",null);
        return cursor;
    }
    public Cursor dispMB() {
        SQLiteDatabase db = this.getReadableDatabase();
        Cursor cursor = db.rawQuery(" Select * from Motherboard ",null);
        return cursor;
    }

    public long getSum() {
        long sum=0;
        SQLiteDatabase db = this.getReadableDatabase();
        Cursor cursor = db.rawQuery(" Select Sum(Cost) from Processor ",null);
        cursor.moveToFirst();
        /*sum+=cursor.getLong(0);
        cursor = db.rawQuery(" Select Sum(Cost) from Processor ",null);
        cursor.moveToFirst();
        sum+=cursor.getLong(0);
        cursor = db.rawQuery(" Select Sum(Cost) from Motherboard ",null);
        cursor.moveToFirst();*/
        sum+=cursor.getLong(0);
        return sum;
    }

    public long totalDevices() {
        long sum=0;
        SQLiteDatabase db = this.getReadableDatabase();
        Cursor cursor = db.rawQuery(" Select Sum(Stock) from Processor ",null);
        cursor.moveToFirst();
        sum+=cursor.getLong(0);
        cursor = db.rawQuery(" Select Sum(Stock) from RAM ",null);
        cursor.moveToFirst();
        sum+=cursor.getLong(0);
        cursor = db.rawQuery(" Select Sum(Stock) from Motherboard ",null);
        cursor.moveToFirst();
        sum+=cursor.getLong(0);
        return sum;
    }

    public String avgRAMval() {
        SQLiteDatabase db = this.getReadableDatabase();
        Cursor cursor = db.rawQuery(" Select Avg(Cost) from RAM ",null);
        cursor.moveToFirst();
        return cursor.getString(0);
    }

    public String CostliestProc() {
        SQLiteDatabase db = this.getReadableDatabase();
        Cursor cursor = db.rawQuery(" Select Max(Cost) from Processor ",null);
        cursor.moveToFirst();
        return cursor.getString(0);
    }

    public String CheapestMB() {
        SQLiteDatabase db = this.getReadableDatabase();
        Cursor cursor = db.rawQuery(" Select Min(Cost) from Motherboard ",null);
        cursor.moveToFirst();
        return cursor.getString(0);
    }

    public String Intel() {
        SQLiteDatabase db = this.getReadableDatabase();
        Cursor cursor = db.rawQuery(" Select Avg(Cost) from Processor where Manufacturer = 'Intel' ",null);
        cursor.moveToFirst();
        return cursor.getString(0);
    }

    public void ReplenishStock(String pKey, String tn, String qty) {
        SQLiteDatabase db = getWritableDatabase();
        String PKname = new String();
        if(tn.equals("RAM"))
            PKname = "RAMno";
        else if(tn.equals("Processor"))
            PKname = "ProcNo";
        else PKname = "MBNo";
        db.execSQL("Update "+tn+" set Stock = "+qty+" where "+PKname+" = '"+pKey+"' ");
        db.close();
    }

    public Cursor getCartDetails(TextView Name, String Phone) {
        SQLiteDatabase db = getReadableDatabase();
        Cursor cursor = db.rawQuery(" Select Name from Customers where Phone = '"+Phone+"' ",null);
        cursor.moveToFirst();
        Name.setText(cursor.getString(0));
        cursor = db.rawQuery(" Select Username from Login where Phone = '"+Phone+"' ",null);
        cursor.moveToFirst();
        return cursor;
    }
}
